import java.io.*;
import org.openqa.selenium.*;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.events.AbstractWebDriverEventListener;

public class CustomEventListener extends AbstractWebDriverEventListener {
  private int index = 0;

	@Override
	public void beforeClickOn(WebElement element, WebDriver driver) {
		takeScreenshot(driver, "screenshot"+(++index)+".png");
	}

	@Override
	public void afterClickOn(WebElement element, WebDriver driver) {
		takeScreenshot(driver, "screenshot"+(++index)+".png");
	}

	protected void takeScreenshot(WebDriver driver, String path) {
    try {
      File out = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
      FileHandler.copy(out, new File(path));
    } catch (IOException ioe) {
      throw new RuntimeException("Failed to take a screenshot. path: "+path);
    }
	}
}
